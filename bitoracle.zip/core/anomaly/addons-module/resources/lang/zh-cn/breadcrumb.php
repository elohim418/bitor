<?php

return [
    'documentation' => '文档',
];
