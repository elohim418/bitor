<?php

return [
    'enable'    => 'Engedélyez',
    'disable'   => 'Letilt',
    'install'   => 'Telepít',
    'uninstall' => 'Eltávolít',
    'activate'  => 'Aktivál',
];