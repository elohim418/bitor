<?php

return [
    'enable'    => 'Aktivieren',  // @todo: check this
    'disable'   => 'Deaktivieren',
    'install'   => 'Installieren',
    'uninstall' => 'Deinstallieren',
    'activate'  => 'Aktivieren',  // @todo: check this
];
