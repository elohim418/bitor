<?php

return [
    'name'        => [
        'name' => 'Name',
    ],
    'state'       => [
        'name' => 'Zustand', // @todo: check this
    ],
    'type'        => [
        'name' => 'Typ',
    ],
    'status'      => [
        'name' => 'Status',
    ],
    'location'    => [
        'name' => 'Standort', // @todo: check this
    ],
    'description' => [
        'name' => 'Beschreibung',
    ],
];
