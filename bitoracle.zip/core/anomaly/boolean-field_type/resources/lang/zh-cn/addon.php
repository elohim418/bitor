<?php

return [
    'title'       => 'Boolean',
    'name'        => 'Boolean 字段类型',
    'description' => '开/关 切换风格字段类型.',
];
