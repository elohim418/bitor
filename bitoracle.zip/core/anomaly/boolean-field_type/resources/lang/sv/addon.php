<?php

return [
    'title'       => 'Boolesk',
    'name'        => 'Boolesk fälttyp',
    'description' => 'Ett fält i stilen av en av/på-brytare.',
];
