<?php

return [
    'install_addon_success'   => 'Addon installato correttamente!',
    'uninstall_addon_success' => 'Addon disinstallato correttamente!',
];