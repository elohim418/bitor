<?php

return [
    'title'       => '联系',
    'name'        => '联系插件',
    'description' => '一个简单的联系表单插件.'
];
