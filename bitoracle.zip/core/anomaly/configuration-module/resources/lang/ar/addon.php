<?php

return [
    'title'       => 'الترتيبات',
    'name'        => 'وحدة الترتيب',
    'description' => 'ادارة وحدة الترتيب.',
];
