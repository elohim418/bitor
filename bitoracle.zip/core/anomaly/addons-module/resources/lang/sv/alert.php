<?php

return [
    'install_module_success'      => 'Modelen :module installerades!',
    'uninstall_module_success'    => 'Modulen :module avinstallerades!',
    'enable_module_success'       => 'Modulen :module aktiverades!',
    'disable_module_success'      => 'Modulen :module inaktiverades!',
    'install_extension_success'   => 'Tillägget :extension installerades!',
    'uninstall_extension_success' => 'Tillägget :extension avinstallerades!',
    'enable_extension_success'    => 'Tillägget :extension aktiverades!',
    'disable_extension_success'   => 'Tillägget :extension inaktiverades!',
    'addon_delete_success'        => 'Tillägget :addon har tagits bort från din server!',
    'addon_delete_error'          => 'Tillägget :addon har INTE tagits bort från din server!',
];
