<?php

return [
    'install_addon_success'   => 'افزونه نصب شد',
    'migrate_addon_success'   => 'مهاجرت افزونه انجام شد',
    'uninstall_addon_success' => 'افزونه حذف شد',
];
