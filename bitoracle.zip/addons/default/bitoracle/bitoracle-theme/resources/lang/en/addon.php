<?php

return [
    'title'       => 'Bitoracle',
    'name'        => 'Bitoracle Theme',
    'description' => ''
];
