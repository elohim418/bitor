<?php

return [
    'enable'    => 'Activar',
    'disable'   => 'Desactivar',
    'install'   => 'Instalar',
    'uninstall' => 'Desinstalar',
];
