<?php

return [
    'title'       => '复选框',
    'name'        => '复选框字段类型',
    'description' => '复选框输入的字段类型.'
];
