<?php

return [
    'placeholder' => 'اختر الاضافة...',
];
