<?php

return [
    'documentation' => '文件',
];
