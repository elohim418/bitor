<?php

return [
    'title' => 'Konfigūracija',
    'name' => 'Modulio konfigūracija',
    'description' => 'Priedo konfigūracijos valdymas',
];
