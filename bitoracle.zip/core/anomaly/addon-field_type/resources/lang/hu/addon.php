<?php

return [
    'title'       => 'Kiegészítő',
    'name'        => 'Kiegészítő Mező Típusa',
    'description' => 'Kiegészítő legördülőlista mező típusa.',
];