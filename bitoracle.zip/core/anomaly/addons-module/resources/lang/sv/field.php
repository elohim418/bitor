<?php

return [
    'name'        => [
        'name' => 'Namn',
    ],
    'state'       => [
        'name' => 'Tillstånd',
    ],
    'type'        => [
        'name' => 'Typ',
    ],
    'status'      => [
        'name' => 'Status',
    ],
    'location'    => [
        'name' => 'Plats',
    ],
    'description' => [
        'name' => 'Beskrivning',
    ],
];
