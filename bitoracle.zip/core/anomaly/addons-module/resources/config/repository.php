<?php

return [
    'featured'  => [
        'url'         => 'https://packages.pyrocms.com',
        'name'        => 'anomaly.module.addons::repository.featured.name',
        'title'       => 'anomaly.module.addons::repository.featured.title',
        'description' => 'anomaly.module.addons::repository.featured.description',
    ],
    'community' => [
        'url'         => 'https://community.pyrocms.com',
        'name'        => 'anomaly.module.addons::repository.community.name',
        'title'       => 'anomaly.module.addons::repository.community.title',
        'description' => 'anomaly.module.addons::repository.community.description',
    ],
//    'development' => [
//        'url'         => 'https://development.pyrocms.com',
//        'name'        => 'anomaly.module.addons::repository.development.name',
//        'title'       => 'anomaly.module.addons::repository.development.title',
//        'description' => 'anomaly.module.addons::repository.development.description',
//    ],
];
