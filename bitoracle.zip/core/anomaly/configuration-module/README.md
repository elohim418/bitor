# Configuration Module

[![License](https://img.shields.io/badge/license-MIT-brightgreen.svg)](https://packagist.org/packages/anomaly/configuration-module) 
[![Build Status](https://scrutinizer-ci.com/g/anomalylabs/configuration-module/badges/build.png?b=master)](https://scrutinizer-ci.com/g/anomalylabs/configuration-module/build-status/master)
[![Code Quality](http://img.shields.io/scrutinizer/g/anomalylabs/configuration-module.svg)](https://scrutinizer-ci.com/g/anomalylabs/configuration-module/)
[![Total Downloads](http://img.shields.io/packagist/dt/anomaly/configuration-module.svg)](https://packagist.org/packages/anomaly/configuration-module)

[![SensioLabsInsight](https://insight.sensiolabs.com/projects/15919ee3-2cac-4e59-b54d-d79afbcf293c/small.png)](https://insight.sensiolabs.com/projects/15919ee3-2cac-4e59-b54d-d79afbcf293c)

Addon configuration management.
