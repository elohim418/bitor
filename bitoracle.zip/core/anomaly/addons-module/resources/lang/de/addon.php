<?php

return [
    'title'       => 'Addons',
    'name'        => 'Addons Modul',
    'description' => 'Addons Verwaltung und Informationen.',
    'section'     => [
        'plugins'     => 'Plugins',
        'themes'      => 'Themes',
        'modules'     => 'Module',
        'extensions'  => 'Erweiterungen',
        'field_types' => 'Feldtypen',
    ],
];
