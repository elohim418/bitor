<?php

return [
    'placeholder' => 'Válassz kiegészítőt...',
];