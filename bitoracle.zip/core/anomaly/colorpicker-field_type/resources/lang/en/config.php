<?php

return [
    'default_value' => [
        'label'        => 'Default Value',
        'instructions' => 'Choose a default color if any.',
    ],
];
