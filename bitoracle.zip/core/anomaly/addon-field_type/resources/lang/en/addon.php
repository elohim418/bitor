<?php

return [
    'title'       => 'Addon',
    'name'        => 'Addon Field Type',
    'description' => 'An addon dropdown field type.',
];
