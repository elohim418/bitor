<?php

return [
    'disabled'    => 'Deaktiviert',
    'uninstalled' => 'Deinstalliert',
    'admin'       => 'Admin',
    'public'      => 'Öffentlich',
];
