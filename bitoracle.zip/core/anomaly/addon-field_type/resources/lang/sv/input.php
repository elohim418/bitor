<?php

return [
    'placeholder' => 'Välj ett tillägg...',
];
