<?php namespace Anomaly\ContactPlugin;

use Anomaly\Streams\Platform\Addon\Plugin\Plugin;

/**
 * Class ContactPlugin
 *
 * @link   http://pyrocms.com/
 * @author PyroCMS, Inc. <support@pyrocms.com>
 * @author Ryan Thompson <ryan@pyrocms.com>
 */
class ContactPlugin extends Plugin
{

}
