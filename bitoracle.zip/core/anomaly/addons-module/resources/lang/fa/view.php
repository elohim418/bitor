<?php

return [
    'disabled'    => 'غیر فعال شده',
    'uninstalled' => 'حدف شده',
    'admin'       => 'ادمین',
    'public'      => 'عموم',
];
