<?php

return [
    'install_module_success'      => 'ماژول :module با موفقیت نصب شد',
    'uninstall_module_success'    => 'ماژول :module با موقیت حذف شد',
    'enable_module_success'       => 'ماژول :module فعال شد',
    'disable_module_success'      => 'ماژول :module غیر فعال شد',
    'install_extension_success'   => 'اکستنشن :extension با موفقیت نصب شد',
    'uninstall_extension_success' => 'اکستنشن :extension حذف شد',
    'enable_extension_success'    => 'اکستنشن :extension فعال شد',
    'disable_extension_success'   => 'اکستنشن :extension غیر فعال شد',
    'addon_delete_success'        => 'افزونه ی :addon از سرور پاک شد',
    'addon_delete_error'          => 'افزونه ی :addon از سرور پاک نــشد',
];
