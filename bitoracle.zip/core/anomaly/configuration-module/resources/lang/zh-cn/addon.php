<?php

return [
    'title'       => '设置',
    'name'        => '设置模块',
    'description' => '增强模块设置管理.',
];
