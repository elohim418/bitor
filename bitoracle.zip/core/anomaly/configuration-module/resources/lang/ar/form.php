<?php

return [
    'section' => [
        'configuration' => 'الترتيبات',
    ],
];
