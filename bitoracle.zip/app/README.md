## The App Directory

You are welcome to use the `app` directory just as you would with any other Laravel application.

PyroCMS uses the [streams-platform](http://github.com/anomalylabs/streams-platform) which extends each of Laravel's kernels. As such they have been removed from here! You can use the `config/streams.php` file to register most necessary services like commands where you would typically put them in the kernel. Remember you can also leverage addon service providers! You may also modify any file in the base installation as it's considered part of your project and not core.
