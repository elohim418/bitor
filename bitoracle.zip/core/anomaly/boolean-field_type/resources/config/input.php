<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default Input Mode
    |--------------------------------------------------------------------------
    |
    | When no input mode is specified, the following mode will be used.
    |
    */
    'mode' => 'switch',

];
