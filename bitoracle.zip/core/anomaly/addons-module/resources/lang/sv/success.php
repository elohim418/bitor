<?php

return [
    'install_modules'      => ':count modul(er) installerades !',
    'uninstall_modules'    => ':count modul(er) avinstallerades !',
    'enable_modules'       => ':count modul(er) aktiverades!',
    'disable_modules'      => ':count modul(er) disabled!',
    'install_extensions'   => ':count tillägg installerades!',
    'uninstall_extensions' => ':count tillägg avinstallerades!',
    'enable_extensions'    => ':count tillägg aktiverades!',
    'disable_extensions'   => ':count tillägg disabled!',
    'activate_theme'       => 'Temat :title aktiverades!',
    'delete_themes'        => ':count tema(n) togs bort!',
    'delete_plugins'       => ':count plugin(s) togs bort!',
];
