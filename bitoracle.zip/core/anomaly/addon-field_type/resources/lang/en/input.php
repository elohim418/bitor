<?php

return [
    'placeholder' => 'Choose an addon...',
];
