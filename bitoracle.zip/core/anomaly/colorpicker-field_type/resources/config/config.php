<?php

return [
    'default_value' => [
        'type'   => 'anomaly.field_type.colorpicker',
        'config' => [
            'format' => 'hex',
        ],
    ],
];
