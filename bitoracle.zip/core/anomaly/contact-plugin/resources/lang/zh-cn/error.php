<?php

return [
    'send_message' => '发送信息时发生错误.'
];
