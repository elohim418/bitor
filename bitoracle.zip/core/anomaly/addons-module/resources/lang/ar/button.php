<?php

return [
    'enable'    => 'تفعيل',
    'disable'   => 'تعطيل',
    'install'   => 'تثبيت',
    'uninstall' => 'إلغاء تثبيت',
    'activate'  => 'تنشيط',
];
