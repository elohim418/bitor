<?php

return [
    'title'       => 'Addon',
    'name'        => 'Modulo Addon',
    'description' => 'Informazioni e gestione Addon',
    'section'     => [
        'plugins' => 'Plugin',
    'themes'      => 'Temi',
    'modules'     => 'Moduli',
    'extensions'  => 'Estensioni',
    'field_types' => 'Field Types',
    ],
];