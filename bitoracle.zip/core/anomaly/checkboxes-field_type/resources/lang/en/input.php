<?php

return [
    'help' => 'Separate values with a comma or by pressing "Enter".'
];
