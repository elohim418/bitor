<?php

return [
    'install_module_success'      => 'A(z) :modul modul sikeresen telepítve.',
    'uninstall_module_success'    => 'A(z) :modul modul eltávolítva.',
    'enable_module_success'       => 'A(z) :modul modul engedélyezve.',
    'disable_module_success'      => 'A(z) :modul modul letiltva.',
    'install_extension_success'   => 'A(z) :extension kiterjesztés sikeresen telepítve.',
    'uninstall_extension_success' => 'A(z) :extension kiterjesztés eltávolítva.',
    'enable_extension_success'    => 'A(z) :extension kiterjesztés engedélyezve.',
    'disable_extension_success'   => 'A(z) :extension kiterjesztés letiltva.',
    'addon_delete_success'        => 'A(z) :addon kiegészítés törölve az oldalról.',
    'addon_delete_error'          => 'A(z) :addon kiegészítés nem törölhető az oldalról.',
];