<?php

return [
    'disable'   => 'Är du säker på att du vill inaktivera?<br><small>Inaktivering kommer INTE påverka tillägget permanent på något sätt.</small>',
    'uninstall' => 'Är du säker på att du vill avinstallera?<br><small>Avinstallering tar bort all funktionalitet såväl som databasinformation.<br>Om ett kärntillägg inaktiveras kan du skada din installation permanent.</b></small>',
];
