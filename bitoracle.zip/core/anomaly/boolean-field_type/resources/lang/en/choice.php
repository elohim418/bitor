<?php
return [
    'yes' => 'Yes',
    'no'  => 'No',
];