<?php

return [
    'enable' => 'Įjungti',
    'disable' => 'Išjungti',
    'install' => 'Instaliuoti',
    'uninstall' => 'Išinstaliuoti',
    'migrate' => 'Migruoti',
    'activate' => 'Aktyvus',
];
