<?php

return [
    'configuration' => [
        'name' => '設定',
    ],
];
