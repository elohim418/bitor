<?php

return [
    'title'       => 'Configuration',
    'name'        => 'Configuration Module',
    'description' => 'Addon configuration management.',
];
