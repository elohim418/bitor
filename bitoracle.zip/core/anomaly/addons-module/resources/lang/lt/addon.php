<?php

return [
    'title' => 'Priedai',
    'name' => 'Priedų modulis',
    'description' => 'Priedų informacija ir valdymas',
    'section' => [
        'plugins' => 'Įskiepis',
        'themes' => 'Tema',
        'modules' => 'Modulis',
        'extensions' => 'Plėtiniai',
        'field_types' => 'Laukų tipai',
    ],
];
