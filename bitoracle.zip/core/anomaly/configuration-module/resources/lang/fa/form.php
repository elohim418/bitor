<?php

return [
    'section' => [
        'configuration' => 'پیکربندی',
    ],
];
