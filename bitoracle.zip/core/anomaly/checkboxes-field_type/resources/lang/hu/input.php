<?php

return [
    'help' => 'Válaszd el az értékeket vesszővel vagy enterrel.',
];