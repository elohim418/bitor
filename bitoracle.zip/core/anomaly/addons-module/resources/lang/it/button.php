<?php

return [
    'enable'    => 'Abilita',
    'disable'   => 'Disabilita',
    'install'   => 'Installa',
    'uninstall' => 'Disinstalla',
    'activate'  => 'Attiva',
];