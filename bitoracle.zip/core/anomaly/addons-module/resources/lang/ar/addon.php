<?php

return [
    'title'       => 'الاضافات',
    'name'        => 'وحدة الاضافات',
    'description' => 'معلومات الوحدة وإدارتها.',
    'section'     => [
        'plugins'     => 'الوصلات',
        'themes'      => 'السمات',
        'modules'     => 'الوحدات',
        'extensions'  => 'التركيبات',
        'field_types' => 'أنواع الحقول',
    ],
];
