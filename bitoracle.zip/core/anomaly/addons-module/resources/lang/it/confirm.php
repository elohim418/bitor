<?php

return [
    'disable' => 'Sei sicuro di voler disabilitare questo Addon?
Disabilitarlo NON causerà nessun effetto permanente.',
    'uninstall' => 'Sei sicuro di voler disinstallare questo Addon?
Disinstallandolo rimuoverai sia le funzionalità che i suoi dati salvati nel database.
Se disinstalli un Addon del Core potresti danneggiare in modo permanente il sistema.',
];