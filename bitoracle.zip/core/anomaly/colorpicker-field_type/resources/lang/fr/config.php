<?php

return [
    'default_value' => [
        'label'        => 'Valeur par défaut',
        'instructions' => 'Choisissez une valeur par défaut. Facultatif.',
    ],
];
