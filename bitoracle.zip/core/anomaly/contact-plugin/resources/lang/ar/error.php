<?php

return [
    'send_message' => 'هناك مشكلة بارسال رسالتك.'
];
