# Checkboxes Field Type

*anomaly.field_type.checkboxes*

#### A checkboxes field type.

The checkboxes field type provides multiple checkbox inputs.
