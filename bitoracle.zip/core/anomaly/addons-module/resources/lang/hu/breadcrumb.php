<?php

return [
    'documentation' => 'Dokumentáció',
];