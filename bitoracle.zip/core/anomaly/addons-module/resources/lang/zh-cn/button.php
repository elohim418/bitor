<?php

return [
    'enable'    => '启用',
    'disable'   => '禁用',
    'install'   => '安装',
    'uninstall' => '卸载',
    'activate'  => '激活',
];
