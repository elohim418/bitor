<?php

return [
    'disabled'    => '已禁用',
    'uninstalled' => '已解除安裝',
    'admin'       => '管理員',
    'public'      => '公開',
];
