# Addon Field Type

*anomaly.field_type.addon*

#### An addon dropdown field type.

The addon field type provides a addons dropdown input.
