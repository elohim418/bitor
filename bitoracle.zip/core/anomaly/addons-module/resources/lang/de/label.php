<?php

return [
    'link'          => 'Link',
    'type'          => 'Typ',
    'path'          => 'Pfad',
    'docs'          => 'Doku',
    'authors'       => 'Autoren',
    'support'       => 'Support',
    'version'       => 'Version',
    'standard'      => 'Standard',
    'information'   => 'Information',
    'irc_channel'   => 'IRC Channel',
    'known_issues'  => 'Bekannte Probleme',
    'project_wiki'  => 'Projekt Wiki',
    'not_installed' => 'Nicht installiert',
    'support_email' => 'Support E-Mail',
    'support_forum' => 'Support Forum',
];
