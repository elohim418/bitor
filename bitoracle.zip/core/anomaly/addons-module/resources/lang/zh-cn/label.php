<?php

return [
    'link'          => '链接',
    'type'          => '类型',
    'path'          => '路径',
    'docs'          => '文档',
    'authors'       => '作者',
    'support'       => '支持',
    'version'       => '版本',
    'standard'      => '标准',
    'namespace'     => '命名空间',
    'information'   => '信息',
    'irc_channel'   => 'IRC 频道',
    'known_issues'  => '已知问题',
    'project_wiki'  => '项目Wiki',
    'not_installed' => '尚未安装',
    'support_email' => '支持Email',
    'support_forum' => '支持Forum',
];
