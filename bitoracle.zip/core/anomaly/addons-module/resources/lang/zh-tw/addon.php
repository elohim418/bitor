<?php

return [
    'title'       => '附加模組',
    'name'        => '附加模組',
    'description' => '附加模組的資訊與管理。',
    'section'     => [
        'plugins'     => '程式插件',
        'themes'      => '主題模板',
        'modules'     => '程式模組',
        'extensions'  => '程式擴充',
        'field_types' => '欄位型別',
    ],
];
