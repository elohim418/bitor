<?php

return [
    'title'       => 'Booléen',
    'name'        => 'Type de champs Booléen',
    'description' => 'Type de champs proposant un choix On / Off',
];
