<?php

return [
    'link'          => 'رابط',
    'type'          => 'نوع',
    'path'          => 'مسار',
    'docs'          => 'مستند',
    'authors'       => 'منشأ',
    'support'       => 'دعم',
    'version'       => 'إضدار',
    'standard'      => 'قياسي',
    'information'   => 'معلومات',
    'irc_channel'   => 'IRC قناة',
    'known_issues'  => 'المشكللات المعروفة',
    'project_wiki'  => 'مشروع ويكي',
    'not_installed' => 'غير مثبت',
    'support_email' => 'بريد اللكتروني للدعم',
    'support_forum' => 'منتدى الدعم',
];
