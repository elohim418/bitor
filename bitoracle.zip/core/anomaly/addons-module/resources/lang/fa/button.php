<?php

return [
    'enable'    => 'فعال کردن',
    'disable'   => 'غیر فعال کردن',
    'install'   => 'نصب کردن',
    'uninstall' => 'حذف کردن',
    'migrate'   => 'مهاجرت دادن',
    'activate'  => 'اکتیو کردن',
];
