<?php

return [
    'yes' => 'Evet',
    'no'  => 'Hayır',
];