<?php

return [
    'install_addon_success'   => 'Addon installé !',
    'uninstall_addon_success' => 'Addon désinstallé !',
];
