<?php

return [
    'title'       => 'Boolean',
    'name'        => 'Boolean Field Type',
    'description' => 'An on/off switch style field type.',
];
