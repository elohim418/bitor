<?php

return [
    'title'       => 'Boole',
    'name'        => 'Boole Alan Tipi',
    'description' => 'Bir kapalı/açık anahtar stili alan tipi',
];