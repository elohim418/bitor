<?php

return [
    'placeholder' => 'Wählen Sie ein Addon...',
];
