<?php

return [
    'link' => 'Nuoroda',
    'type' => 'Tipas',
    'path' => 'Kelias',
    'docs' => 'Dokumentai',
    'authors' => 'Autoriai',
    'support' => 'Pagalba',
    'version' => 'Versija',
    'standard' => 'Standartinis',
    'namespace' => 'Namespace',
    'information' => 'Informacija',
    'irc_channel' => 'IRC kanalas',
    'known_issues' => 'Žinomos problemos',
    'project_wiki' => 'Wiki projektas',
    'not_installed' => 'Neinstaliuota',
    'support_email' => 'Pagalbos el.paštas',
    'support_forum' => 'Pagalbos forumas',
];
