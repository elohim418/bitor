<?php

return [
    'title'       => 'Checkboxen',
    'name'        => 'Checkbox Feldtyp',
    'description' => 'Ein Feldtyp für Checkboxen.'
];
