<?php

return [
    'install_addon_success'   => 'Kiegészítő sikeresen telepítve.',
    'uninstall_addon_success' => 'Kiegészítő sikeresen eltávolítva.',
];
