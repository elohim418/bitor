<?php

return [
    'title' => '附加模組',
    'name' => '附加模組欄位型別',
    'description' => '一個附加模組的下拉欄位型別',
];