<?php

return [
    'help' => '各个值之间用英文逗号分隔或使用 "Enter".'
];
