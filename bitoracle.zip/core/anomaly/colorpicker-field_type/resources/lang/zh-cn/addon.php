<?php

return [
    'title'       => '颜色选择器',
    'name'        => '颜色选择器字段类型',
    'description' => '颜色选择器字段类型.',
];
