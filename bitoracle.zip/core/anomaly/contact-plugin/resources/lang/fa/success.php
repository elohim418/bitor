<?php

return [
    'send_message' => 'پیام شما ارسال شد. سپاس',
];
