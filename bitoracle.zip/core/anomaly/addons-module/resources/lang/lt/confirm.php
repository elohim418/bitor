<?php

return [
    'disable' => 'Ar tikrai norite išjungti?
Išjungimas iš esmės nieko nesugadins, galėsite įjungti.',
    'uninstall' => 'Ar tikrai norite išinstaliuoti?
Išinstaliavimas reiškia tai, kad prarasite visą funkcionalumą ir duomenų bazės informaciją taip pat.
Jei išinstaliuojate branduolio priedą galite visiškai sugadinti projekto instaliaciją.',
];
