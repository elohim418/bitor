# Boolean Field Type

*anomaly.field_type.boolean*

#### An on/off switch style field type.

The boolean field type provides an on/off style switch input.
