<?php

return [
    'disabled'    => 'Désactivé',
    'uninstalled' => 'Désinstallé',
    'admin'       => 'Admin',
    'public'      => 'Partie publique',
];
