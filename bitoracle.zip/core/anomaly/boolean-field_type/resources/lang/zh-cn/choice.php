<?php
return [
    'yes' => '是',
    'no'  => '否',
];