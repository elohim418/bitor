<?php

return [
    'disable'   => '确定要禁用吗?<br><small>禁用并不会对增强模块有损害.</small>',
    'uninstall' => '确定要卸载吗?<br><small>卸载会移除所有功能和数据库内容.<br>若移除核心增强模块或会造成无法恢复的损害.</b></small>',
];
