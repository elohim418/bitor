<?php

return [
    'configuration' => [
        'name' => 'الترتيبات',
    ],
];
