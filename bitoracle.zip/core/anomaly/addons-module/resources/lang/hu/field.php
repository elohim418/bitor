<?php

return [
    'name' => [
        'name' => 'Név',
    ],
    'state' => [
        'name' => 'Státusz',
    ],
    'type' => [
        'name' => 'Típus',
    ],
    'status' => [
        'name' => 'Státusz',
    ],
    'location' => [
        'name' => 'Hely',
    ],
    'description' => [
        'name' => 'Leírás',
    ],
    'seed' => [
        'label'    => 'Feltöltsük adattal a kiegészítőt a telepítés alatt?',
    'instructions' => 'Töltsük fel adattal segítségnek / bemutatásnak.',
    'option'       => 'Igen, töltsük fel adattal a telepítés alatt.',
    ],
];