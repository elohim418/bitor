<?php

return [
    'install_module_success'      => 'لقد تم تثبيت وحدة :module بنجاح',
    'uninstall_module_success'    => 'لقد تم إزالة وحدة :module !',
    'enable_module_success'       => 'لقد تم تفعيل وحدة :module !',
    'disable_module_success'      => 'لقد تم تعطيل وحدة :module !',
    'install_extension_success'   => 'لقد تم تثبيت الملحق :extension بنجاح!',
    'uninstall_extension_success' => 'لقد تم إزالة الملحق :extension !',
    'enable_extension_success'    => 'لقد تم تفعيل الملحق :extension !',
    'disable_extension_success'   => 'لقد تم تعطيل الملحق :extension !',
    'addon_delete_success'        => 'لقد تم حذف الإضافة :addon من المخدم!',
    'addon_delete_error'          => 'لايمكن حذف الإضافة :addon من المخدم!',
];
