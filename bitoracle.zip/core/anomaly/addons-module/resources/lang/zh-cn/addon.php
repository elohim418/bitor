<?php

return [
    'title'       => '增强模块',
    'name'        => '增强模块',
    'description' => '增强模块信息和管理.',
    'section'     => [
        'plugins'     => '插件',
        'themes'      => '主题模板',
        'modules'     => '模块',
        'extensions'  => '扩展',
        'field_types' => '字段类型',
    ],
];
