<?php

return [
    'title'       => 'Colorpicker',
    'name'        => 'Colorpicker Field Type',
    'description' => 'A colorpicker field type.',
];
