<?php

return [
    'link'          => 'Link',
    'type'          => 'Tipo',
    'path'          => 'Path',
    'docs'          => 'Docs',
    'authors'       => 'Autori',
    'support'       => 'Supporto',
    'version'       => 'Versione',
    'standard'      => 'Standard',
    'information'   => 'Informazione',
    'irc_channel'   => 'Canale IRC',
    'known_issues'  => 'Problemi noti',
    'project_wiki'  => 'Wiki del progetto',
    'not_installed' => 'Non installato',
    'support_email' => 'Supporto Email',
    'support_forum' => 'Supporto Forum',
];