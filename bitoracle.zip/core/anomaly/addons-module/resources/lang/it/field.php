<?php

return [
    'name' => [
        'name' => 'Nome',
    ],
    'state' => [
        'name' => 'Stato',
    ],
    'type' => [
        'name' => 'Tipo',
    ],
    'status' => [
        'name' => 'Stato',
    ],
    'location' => [
        'name' => 'Posizione',
    ],
    'description' => [
        'name' => 'Descrizione',
    ],
    'seed' => [
        'label'    => 'Eseguire i Seed durante l&#039;installazione?',
    'instructions' => 'I dati di Seed aiutano la configurazione e la dimostrazione delle funzionalità dell&#039;addon.',
    'option'       => 'Si, includi i dati di seed durante l&#039;installazione',
    ],
];