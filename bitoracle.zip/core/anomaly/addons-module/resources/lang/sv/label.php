<?php

return [
    'link'          => 'Länk',
    'type'          => 'Typ',
    'path'          => 'Sökväg',
    'docs'          => 'Dokument',
    'authors'       => 'Författare',
    'support'       => 'Support',
    'version'       => 'Version',
    'standard'      => 'Standard',
    'information'   => 'Information',
    'irc_channel'   => 'IRC-kanal',
    'known_issues'  => 'Kända Problem',
    'project_wiki'  => 'Projektwiki',
    'not_installed' => 'Inte Installerad',
    'support_email' => 'Supportmejl',
    'support_forum' => 'Supportforum',
];
