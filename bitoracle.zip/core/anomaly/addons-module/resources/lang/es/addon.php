<?php

return [
    'name'        => 'Componentes',
    'description' => 'Información de componentes y herramientas de administración.',
    'section'     => [
        'plugins'     => 'Plugins',
        'themes'      => 'Plantillas',
        'modules'     => 'Módulos',
        'extensions'  => 'Extensiones',
        'field_types' => 'Tipos de Campo',
    ],
];
