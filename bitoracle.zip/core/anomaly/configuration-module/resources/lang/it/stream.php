<?php

return [
    'configuration' => [
        'name' => 'Configurazione',
    ],
];