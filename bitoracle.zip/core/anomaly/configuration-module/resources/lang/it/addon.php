<?php

return [
    'title'       => 'Configurazione',
    'name'        => 'Configurazione Modulo',
    'description' => 'Gestione configurazione Addon',
];