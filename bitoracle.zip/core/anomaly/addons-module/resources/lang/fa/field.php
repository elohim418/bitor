<?php

return [
    'name'        => [
        'name' => 'نام',
    ],
    'state'       => [
        'name' => 'حالت',
    ],
    'type'        => [
        'name' => 'نوع',
    ],
    'status'      => [
        'name' => 'وضعیت',
    ],
    'location'    => [
        'name' => 'محل',
    ],
    'description' => [
        'name' => 'شرح',
    ],
    'seed'        => [
        'label'        => 'آیا به همگام نصب عملیات seed هم انجام شود.',
        'instructions' => 'اصلاعات seed کمک می کنند تا اطلاعات پیش فرض در دیتابیس ذخیره شوند.',
        'option'       => 'بله، عملیات seed انجام شود.',
    ],
];
