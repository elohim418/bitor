<?php

return [
    'disabled'    => '禁用',
    'uninstalled' => '卸载',
    'admin'       => '后台',
    'public'      => '前台',
];
