<?php

return [
    'title'       => 'چک باکس ها',
    'name'        => 'نوع-فیلد چک باکس',
    'description' => 'ورودی نوع چک باکس'
];
