<?php

return [
    'disabled'    => 'Letiltva',
    'uninstalled' => 'Eltávolítva',
    'admin'       => 'Admin',
    'public'      => 'Publikus',
];