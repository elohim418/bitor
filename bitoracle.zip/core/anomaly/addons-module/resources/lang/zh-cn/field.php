<?php

return [
    'name'        => [
        'name' => '名称',
    ],
    'state'       => [
        'name' => '状态',
    ],
    'type'        => [
        'name' => '类型',
    ],
    'status'      => [
        'name' => '当前状态',
    ],
    'location'    => [
        'name' => '位置',
    ],
    'description' => [
        'name' => '描述',
    ],
    'seed'        => [
        'label'        => '同时安装增强模块的样本数据?',
        'instructions' => '样本数据对增强模块的设置和演示有助益.',
        'option'       => '是的, 安装时包含样本数据.',
    ],
];
