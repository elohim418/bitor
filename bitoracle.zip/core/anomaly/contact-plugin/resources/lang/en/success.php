<?php

return [
    'send_message' => 'Your message has been sent! Thank you.',
];
