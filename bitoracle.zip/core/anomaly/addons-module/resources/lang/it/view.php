<?php

return [
    'disabled'    => 'Disabilitato',
    'uninstalled' => 'Disinstallato',
    'admin'       => 'Admin',
    'public'      => 'Pubblico',
];