<?php

return [
    'title'       => 'اتصال',
    'name'        => 'وصلة الاتصال',
    'description' => 'وصلة نموذج اتصال بسيط.'
];
