<?php

return [
    'title' => 'Jelölőnégyzetek',
    'name' => 'Jelölőnégyzetek Mező Típus',
    'description' => 'Jelölőnégyzetek bekérő mező típus.',
];