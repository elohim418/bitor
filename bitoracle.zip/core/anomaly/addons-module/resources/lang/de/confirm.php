<?php

return [
    'disable'   => 'Sind Sie sicher, dass Sie deaktivieren möchten?<br><small>Die Deaktivierung hat keinerlei Einfluss auf das Addon selbst.</small>',
    'uninstall' => 'Sind Sie sicher, dass Sie deinstallieren möchten?<br><small>Eine Deinstallation entfernt alle Funktionalitäten und Datenbankeinträge.<br>Wenn Sie ein &laquo;Core&raquo; Addon deinstallieren, kann Ihre Installation permanent beschädigt werden.</b></small>',
];
