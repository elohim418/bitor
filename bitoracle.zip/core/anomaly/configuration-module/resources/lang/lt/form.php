<?php

return [
    'section' => [
        'configuration' => 'Konfigūracija',
    ],
];
