<?php

return [
    'title'       => 'Cases à cocher',
    'name'        => 'Type de champs Cases à cocher',
    'description' => 'Type de champs pour utiliser des cases à cocher.'
];
