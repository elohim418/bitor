<?php

return [
    'disable' => 'Biztosan le akarod tiltani?
A letiltás nincs végleges kihatással a kiegészítőre.',
    'uninstall' => 'Biztosan el akarod távolítani?
Az eltávolítás minden funkcionális és adatbázis kapcsolatot töröl.
Ha eltávolítod az alap kiegészítéseket a rendszer működését veszélyezteted.',
];