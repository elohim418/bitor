<?php

return [
    'enable'    => '啟用',
    'disable'   => '禁用',
    'install'   => '安裝',
    'uninstall' => '移除',
    'activate'  => '啟動',
];
