<?php

return [
    'install_addon_success' => 'Priedai sėkmingai instaliuoti',
    'migrate_addon_success' => 'Priedai sėkmingai numigruoti',
    'uninstall_addon_success' => 'Priedai sėkmingai išinstaliuoti',
];
