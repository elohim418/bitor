<?php

return [
    'on'  => 'PÅ',
    'off' => 'AV',
    'yes' => 'JA',
    'no'  => 'NEJ',
];
