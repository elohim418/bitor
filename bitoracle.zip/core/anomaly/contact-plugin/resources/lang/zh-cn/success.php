<?php

return [
    'send_message' => '非常感谢, 您的信息已成功发送.'
];
