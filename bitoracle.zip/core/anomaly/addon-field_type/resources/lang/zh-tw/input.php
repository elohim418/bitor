<?php

return [
    'placeholder' => '請選擇附加模組...',
];