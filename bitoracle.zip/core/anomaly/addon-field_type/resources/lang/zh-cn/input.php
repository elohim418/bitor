<?php

return [
    'placeholder' => '请选择一个增强模块...',
];