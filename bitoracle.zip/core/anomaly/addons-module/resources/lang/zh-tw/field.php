<?php

return [
    'name'        => [
        'name' => '名稱',
    ],
    'state'       => [
        'name' => '狀態',
    ],
    'type'        => [
        'name' => '型別',
    ],
    'status'      => [
        'name' => '狀態',
    ],
    'location'    => [
        'name' => '位置',
    ],
    'description' => [
        'name' => '說明',
    ],
    'seed'        => [
        'label'        => '安裝時一併安裝範例資料？',
        'instructions' => '範例資料可以幫助安裝或展示這個附加元件。',
        'option'       => '是的，請在安裝時一併安裝範例資料。',
    ],
];
