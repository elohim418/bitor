<?php
return [
    'yes' => 'بله',
    'no'  => 'خیر',
];