<?php

return [
    'section' => [
        'configuration' => 'Configuration',
    ],
];
