<?php

return [
    'documentation' => 'Dokumentation',
];
