<?php

return [
    'disable'   => 'Etes-vous sûr de vouloir désactiver cet addon ?<br><small>Désactiver ne supprimera aucune donnée.</small>',
    'uninstall' => 'Etes-vous sûr de vouloir supprimer cet addon ?<br><small>La suppression effacera toute donnée relative à l\'addon.<br>Supprimer un addon du "core" peut rendre instable votre site.</b></small>',
];
