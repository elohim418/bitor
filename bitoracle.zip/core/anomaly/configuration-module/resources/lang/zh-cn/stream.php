<?php

return [
    'configuration' => [
        'name' => '设置',
    ],
];
