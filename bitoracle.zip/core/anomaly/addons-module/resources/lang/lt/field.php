<?php

return [
    'name' => [
        'name' => 'Vardas',
    ],
    'state' => [
        'name' => 'Būsena',
    ],
    'type' => [
        'name' => 'Tipas',
    ],
    'status' => [
        'name' => 'Statusas',
    ],
    'location' => [
        'name' => 'Lokacija',
    ],
    'description' => [
        'name' => 'Aprašymas',
    ],
    'seed' => [
        'label' => 'Palikti pradinę informaciją instaliacijos metu',
        'instructions' => 'Palikti priedo pagalbos nustatymus / demonstracinius duomenis',
        'option' => 'Palikti priedo pirminius duomenis',
    ],
];
