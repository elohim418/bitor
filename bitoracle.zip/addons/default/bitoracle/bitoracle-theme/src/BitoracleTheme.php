<?php namespace Bitoracle\BitoracleTheme;

use Anomaly\Streams\Platform\Addon\Theme\Theme;

class BitoracleTheme extends Theme
{

}
