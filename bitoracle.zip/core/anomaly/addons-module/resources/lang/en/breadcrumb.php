<?php

return [
    'documentation' => 'Documentation',
];
