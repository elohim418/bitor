<?php

return [
    'install_addon_success'   => 'تم تثبيت اللإضافة بنجاح!',
    'uninstall_addon_success' => 'تم إلغاء تثبيت الإضافة بنجاح!',
];
