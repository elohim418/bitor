# Colorpicker Field Type

*anomaly.field_type.checkboxes*

A colorpicker field type.
