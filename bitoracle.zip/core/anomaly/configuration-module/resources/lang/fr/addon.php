<?php

return [
    'title'       => 'Configuration',
    'name'        => 'Module Configuration',
    'description' => 'Gestion de la configuration.',
];
