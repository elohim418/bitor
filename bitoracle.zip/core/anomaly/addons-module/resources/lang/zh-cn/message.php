<?php

return [
    'install_addon_success'   => '已成功安装增强模块!',
    'uninstall_addon_success' => '已成功卸载增强模块!',
];
