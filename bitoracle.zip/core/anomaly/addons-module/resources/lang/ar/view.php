<?php

return [
    'disabled'    => 'معطل',
    'uninstalled' => 'غير مثبت',
    'admin'       => 'مدير',
    'public'      => 'عام',
];
