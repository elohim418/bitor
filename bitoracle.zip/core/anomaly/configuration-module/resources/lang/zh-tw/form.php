<?php

return [
    'section' => [
        'configuration' => '設定',
    ],
];
