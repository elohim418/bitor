<?php

return [
    'disabled' => 'Išjungtas',
    'uninstalled' => 'Išinstaliuotas',
    'admin' => 'Administratoriaus',
    'public' => 'Viešas',
];
