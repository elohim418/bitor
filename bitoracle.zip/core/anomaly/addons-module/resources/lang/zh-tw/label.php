<?php

return [
    'link'          => '連結',
    'type'          => '型別',
    'path'          => '路徑',
    'docs'          => '文件',
    'authors'       => '作者',
    'support'       => '支援',
    'version'       => '版本',
    'standard'      => '標準',
    'information'   => '資訊',
    'irc_channel'   => 'IRC 頻道',
    'known_issues'  => '已知問題',
    'project_wiki'  => '專案 Wiki',
    'not_installed' => '尚未安裝',
    'support_email' => '支援信箱',
    'support_forum' => '支援論壇',
];
