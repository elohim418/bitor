<?php

return [
    'install_addon_success'   => '模組成功的安裝了。',
    'uninstall_addon_success' => '模組成功的移除了。',
];
