<?php

return [
    'section' => [
        'configuration' => '设置',
    ],
];
