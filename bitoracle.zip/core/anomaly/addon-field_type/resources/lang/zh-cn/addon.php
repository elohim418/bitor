<?php

return [
    'title' => '增强模块',
    'name' => '增强模块字段类型',
    'description' => '增强模块下拉菜单字段类型',
];