<?php

return [
    'title'       => 'Contact',
    'name'        => 'Contact Plugin',
    'description' => 'A simple contact form plugin.',
];
