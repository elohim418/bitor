<?php

return [
    'send_message' => 'در هنگام ارسال پیام خطایی رخ داد',
];
