<?php

return [
    'link'          => 'لینک',
    'type'          => 'نوع',
    'path'          => 'مسیر',
    'docs'          => 'مستندات',
    'authors'       => 'پدیدآوران',
    'support'       => 'پشتیبانی',
    'version'       => 'ورژن',
    'standard'      => 'استاندارد',
    'namespace'     => 'فضای نام',
    'information'   => 'اطلاعات',
    'irc_channel'   => 'IRC کانال',
    'known_issues'  => 'اشکالات شناخته شده',
    'project_wiki'  => 'پروژه Wiki',
    'not_installed' => 'نصب نشده',
    'support_email' => 'ایمیل پشتیبانی',
    'support_forum' => 'انجمن پشتیبانی',
];
