<?php

return [
    'title'       => 'Choix de couleur',
    'name'        => 'Type de champs choix de couleur',
    'description' => 'Type de champs permettant de choisir une couleur.',
];
