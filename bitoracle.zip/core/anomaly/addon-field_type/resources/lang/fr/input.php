<?php

return [
    'placeholder' => 'Choisissez un addon',
];
