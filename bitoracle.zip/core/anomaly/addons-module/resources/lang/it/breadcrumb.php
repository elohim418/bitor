<?php

return [
    'documentation' => 'Documentazione',
];