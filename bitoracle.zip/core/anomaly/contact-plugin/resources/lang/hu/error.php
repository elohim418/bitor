<?php

return [
    'send_message' => 'Hiba az üzenet küldése közben.',
];