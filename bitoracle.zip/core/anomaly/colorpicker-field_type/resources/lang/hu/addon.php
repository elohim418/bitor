<?php

return [
    'title'       => 'Színválasztó',
    'name'        => 'Színválasztő Mező Típus',
    'description' => 'Színválasztó mező típus.',
];