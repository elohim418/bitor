<?php

return [
    'documentation' => 'مستندات',
];
