<?php
return [
    'yes' => 'نعم',
    'no'  => 'لا',
];
