<?php

return [
    'title'       => 'Addon',
    'name'        => 'Type de champs Addon',
    'description' => 'Type de champs proposant la liste des addons.',
];
