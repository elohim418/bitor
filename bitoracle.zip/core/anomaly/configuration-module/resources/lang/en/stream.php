<?php

return [
    'configuration' => [
        'name' => 'Configuration',
    ],
];
