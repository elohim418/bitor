<?php

return [
    'send_message' => 'Az üzeneted elküldtük! Köszönjük!',
];