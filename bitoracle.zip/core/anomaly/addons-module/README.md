# Addons Module

[![License](https://img.shields.io/badge/license-MIT-brightgreen.svg)](https://packagist.org/packages/anomaly/addons-module) 
[![Build Status](https://scrutinizer-ci.com/g/anomalylabs/addons-module/badges/build.png?b=master)](https://scrutinizer-ci.com/g/anomalylabs/addons-module/build-status/master)
[![Code Quality](http://img.shields.io/scrutinizer/g/anomalylabs/addons-module.svg)](https://scrutinizer-ci.com/g/anomalylabs/addons-module/)
[![Total Downloads](http://img.shields.io/packagist/dt/anomaly/addons-module.svg)](https://packagist.org/packages/anomaly/addons-module)

[![SensioLabsInsight](https://insight.sensiolabs.com/projects/81982ec5-cbe1-499f-aafc-3d75c747a4fd/small.png)](https://insight.sensiolabs.com/projects/81982ec5-cbe1-499f-aafc-3d75c747a4fd)

Addon information and management.
