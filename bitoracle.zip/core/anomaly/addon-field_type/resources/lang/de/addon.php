<?php

return [
    'title'       => 'Addon',
    'name'        => 'Addon Feldtyp',
    'description' => 'Ein Feldtyp der Addons in einem Dropdown auflistet.',
];
