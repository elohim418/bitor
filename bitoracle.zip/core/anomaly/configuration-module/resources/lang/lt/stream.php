<?php

return [
    'configuration' => [
        'name' => 'Konfigūracija',
    ],
];
