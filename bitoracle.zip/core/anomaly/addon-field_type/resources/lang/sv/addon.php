<?php

return [
    'title'       => 'Tillägg',
    'name'        => 'Tillägsfälttyp',
    'description' => 'En fälttyp för tillägg genom dropdown.',
];
