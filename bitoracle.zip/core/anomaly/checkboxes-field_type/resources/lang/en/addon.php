<?php

return [
    'title'       => 'Checkboxes',
    'name'        => 'Checkboxes Field Type',
    'description' => 'A checkboxes input field type.'
];
