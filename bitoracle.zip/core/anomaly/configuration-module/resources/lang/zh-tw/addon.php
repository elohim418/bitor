<?php

return [
    'title'       => '設定',
    'name'        => '設定模組',
    'description' => '附加元件設定管理',
];
