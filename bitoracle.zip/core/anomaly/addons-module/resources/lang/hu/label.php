<?php

return [
    'link'          => 'Link',
    'type'          => 'Típus',
    'path'          => 'Útvonal',
    'docs'          => 'Dokumentáció',
    'authors'       => 'Szerzők',
    'support'       => 'Támogatás',
    'version'       => 'Verzió',
    'standard'      => 'Alap',
    'information'   => 'INformáció',
    'irc_channel'   => 'IRC Csatorna',
    'known_issues'  => 'Ismert Hibák',
    'project_wiki'  => 'Projekt Wiki',
    'not_installed' => 'Nem telepített',
    'support_email' => 'Támogatói Email cím',
    'support_forum' => 'Támogatói Fórum',
];