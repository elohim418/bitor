<?php

return [
    'downloaded' => 'Downloaded',
    'available'  => 'Available',
    'community'  => 'Community',
    'updates'    => 'Updates',
    'all'        => 'All',
];
