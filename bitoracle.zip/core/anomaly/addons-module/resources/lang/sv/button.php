<?php

return [
    'enable'    => 'Aktivera',
    'disable'   => 'Inaktivera',
    'install'   => 'Installera',
    'uninstall' => 'Avinstallera',
    'activate'  => 'Aktivera',
];
