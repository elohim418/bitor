<?php

return [
    'enable'    => 'Enable',
    'remove'    => 'Remove',
    'update'    => 'Update',
    'disable'   => 'Disable',
    'install'   => 'Install',
    'migrate'   => 'Migrate',
    'download'  => 'Download',
    'uninstall' => 'Uninstall',
];
