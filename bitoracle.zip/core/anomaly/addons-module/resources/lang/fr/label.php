<?php

return [
    'link'          => 'Lien',
    'type'          => 'Type',
    'path'          => 'Chemin',
    'docs'          => 'Documentation',
    'authors'       => 'Auteurs',
    'support'       => 'Support',
    'version'       => 'Version',
    'standard'      => 'Standard',
    'information'   => 'Information',
    'irc_channel'   => 'Channel IRC',
    'known_issues'  => 'Problèmes connus',
    'project_wiki'  => 'Page Wiki du projet',
    'not_installed' => 'Non installé',
    'support_email' => 'Email de support',
    'support_forum' => 'Forum de support',
];
