<?php

return [
    'install_module_success' => ':module modulis sėkmingai instaliuotas!',
    'uninstall_module_success' => ':module modulis sėkmingai išinstaliuotas!',
    'enable_module_success' => ':module modulis buvo įjungtas!',
    'disable_module_success' => ':module modulis buvo išjungtas!',
    'install_extension_success' => ':extention plėtinys sėkmingai instaliuotas!',
    'uninstall_extension_success' => ':extention plėtinys sėkmingai išinstaliuotas!',
    'enable_extension_success' => ':extention plėtinys buvo įjungtas!',
    'disable_extension_success' => ':extention plėtinys buvo išjungtas!',
    'addon_delete_success' => ':addon priedas buvo ištrintas iš serverio!',
    'addon_delete_error' => ':addon priedas negali būti ištrintas iš serverio!',
];
