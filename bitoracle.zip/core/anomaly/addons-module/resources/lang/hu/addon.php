<?php

return [
    'title'       => 'Kiegészítők',
    'name'        => 'Kiegészítő Modulok',
    'description' => 'Kiegészítő információk és kezelés.',
    'section'     => [
        'plugins' => 'Beépülők',
    'themes'      => 'Témák',
    'modules'     => 'Modulok',
    'extensions'  => 'Kiterjesztések',
    'field_types' => 'Mező Típusok',
    ],
];