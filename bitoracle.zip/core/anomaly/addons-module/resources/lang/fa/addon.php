<?php

return [
    'title'       => 'افزونه ها',
    'name'        => 'ماژول افزونه ها',
    'description' => 'اطلاعات افزونه ها و مدیرت آنها',
    'section'     => [
        'plugins'     => 'پلاگین ها',
        'themes'      => 'قالب ها',
        'modules'     => 'ماژول ها',
        'extensions'  => 'اکتنشن ها',
        'field_types' => 'نوع-فیلد ها',
    ],
];
