<?php

return [
    'documentation' => 'الموثقات',
];
