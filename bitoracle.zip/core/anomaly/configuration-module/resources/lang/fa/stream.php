<?php

return [
    'configuration' => [
        'name' => 'پیکربندی',
    ],
];
