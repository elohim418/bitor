<?php

return [
    'title'       => 'Kapcsolatfelvétel',
    'name'        => 'Kapcsolatfelvétel Plugin',
    'description' => 'Egyszerű Kapcsolatfelvétel űrlap plugin.',
];