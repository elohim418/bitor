<?php

return [
    'documentation' => 'Dokumentacija',
];
