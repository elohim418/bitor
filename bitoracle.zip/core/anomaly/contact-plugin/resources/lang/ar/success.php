<?php

return [
    'send_message' => 'شكر! لقد تم ارسال رسالتك.'
];
