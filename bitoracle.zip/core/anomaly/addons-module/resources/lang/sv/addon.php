<?php

return [
    'title'       => 'Tillägg',
    'name'        => 'Tilläggsmodul',
    'description' => 'Tilläggsinformation och hantering.',
    'section'     => [
        'plugins'     => 'Plugins',
        'themes'      => 'Teman',
        'modules'     => 'Moduler',
        'extensions'  => 'Tillägg',
        'field_types' => 'Fälttyper',
    ],
];
