<?php

return [
    'enable'    => 'Activer',
    'disable'   => 'Désactiver',
    'install'   => 'Installer',
    'uninstall' => 'Désinstaller',
    'activate'  => 'Activer',
];
