<?php

return [
    'disabled'    => 'Inaktiverad',
    'uninstalled' => 'Avinstallerad',
    'admin'       => 'Admin',
    'public'      => 'Offentlig',
];
