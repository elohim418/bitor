$(function () {

    // Go!
});
