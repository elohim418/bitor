<?php namespace Bitoracle\BitoracleTheme\Test\Feature;

class BitoracleThemeTest extends \TestCase
{

    public function testFeature()
    {
        $this->markTestSkipped('Not implemented.');
    }
}
