<?php

return [
    'send_message' => 'There was a problem sending your message.',
];
