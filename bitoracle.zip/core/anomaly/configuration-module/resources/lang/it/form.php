<?php

return [
    'section' => [
        'configuration' => 'Configurazione',
    ],
];