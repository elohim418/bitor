<?php

return [
    'title'       => 'بولین',
    'name'        => 'نوع فیلد بولین',
    'description' => 'یک سویچ بله خیر',
];
